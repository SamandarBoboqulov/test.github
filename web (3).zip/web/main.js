document.querySelector('button')

function sun(){
    let element = document.body;
    element.classList.toggle("tunn")
}

function delet(){
    document.getElementById("rek").innerHTML="";
}
